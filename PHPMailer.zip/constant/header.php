<header>
    <div class="responsive">
        <input type="checkbox" name="" id="menubtn" class="menubtn"> 
        <label for="menubtn" class="menuicon">
            <span class="navicon"></span>
        </label>
            
        <ul class="mainmenu">
            <li><a class="active" href="index.php">Home</a></li>
            <li><a href="services.php">Our services</a></li>
            <li><a href="choose.php">Why Choose Us</a></li>
            <li><a href="industries.php">Industries</a></li>
            <li><a href="tools.php">Tool & Tips</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </div>
    <div class="normal">
        <div class="nav">
            <ul>
                <li><a class="active" href="index.php">Home</a></li>
                <li><a href="services.php">Our services</a></li>
                <li><a href="choose.php">Why Choose Us</a></li>
                <li><a href="industries.php">Industries</a></li>
                <li><a href="tools.php">Tool & Tips</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>

        <div class="imagehader">
            <div class="logo">
                <a href="index.php"><img src="media\logo1 (2).png" alt=""></a>
            </div>
        </div>
    </div>
</header>


