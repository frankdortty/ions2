<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['valid'])) {
    header("Location: login.php");
    exit(); 
}

// Include database connection
include("conn.php");

// Delete file if delete button is clicked
if(isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];

    // Fetch file path from database
    $sql = "SELECT file, image FROM upload_file WHERE id='$id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $filePath = $row['file'];
    $imagePath = $row['image'];

    // Delete file from folder
    if (unlink($filePath) && unlink($imagePath)) {
        // Delete record from database
        $deleteSql = "DELETE FROM upload_file WHERE id='$id'";
        if(mysqli_query($conn, $deleteSql)) {
            $message = "File deleted successfully.";
        } else {
            $message = "Error deleting file from database: " . mysqli_error($conn);
        }
    } else {
        $message = "Error deleting file from folder.";
    }
}

// Fetch data from the upload_file table
$sql = "SELECT * FROM upload_file";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uploaded Files</title>
    <link rel="stylesheet" href="style.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="mainBody">
        <div class="left">
            <?php include_once('leftBar.php'); ?>
        </div>
        <div class="right">
            <div class="editDelete">
                <h2>Uploaded Files</h2>
                <?php if (isset($message)) echo "<p>$message</p>"; ?>
                <table>
                    <tr>
                        <th>File Name</th>
                        <th>File</th>
                        <th>Author</th>
                        <th>Author Image</th>
                        <th>Operation</th>
                    </tr>
                    <?php
                    // Display data in table rows
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row["fileName"] . "</td>";
                            echo "<td><a href='" . $row["file"] . "' target='_blank'>View file</a></td>"; // Assuming file field stores the file path
                            echo "<td>" . $row["author"] . "</td>";
                            echo "<td><img src='" . $row["image"] . "' alt='Uploader Image' style='width: 100px; height: auto;'></td>";
                            echo "<td><a href='?delete_id=" . $row["id"] . "' onclick='return confirm(\"Are you sure you want to delete this file?\")'>Delete</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No files found.</td></tr>";
                    }
                    ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>

<?php
// Close database connection
mysqli_close($conn);
?>
