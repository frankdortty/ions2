<?php
session_start();

if (!isset($_SESSION['valid'])) {
    header("Location: login.php");
    exit(); 
}

include("conn.php");

if (isset($_POST['submit'])){
    $name = $_POST['authorsName'];
    $user = $_SESSION['id'];
    $uploadDate = date("Y-m-d H:i:s");

    if ($_FILES["docFiles"]["error"] === 4){
        echo "<script>alert('File Does Not Exist');</script>";
    }else{
        $fileName = $_FILES['docFiles']['name'];
        $fileSize = $_FILES['docFiles']['size'];
        $tmpName = $_FILES['docFiles']['tmp_name'];

        $validFileExtension = ['pdf','JPG', 'JPEG', 'PNG', ];
        $fileExtension = explode('.',$fileName);
        $fileExtension = strtolower(end($fileExtension));
        if(!in_array($fileExtension, $validFileExtension)){
            echo "<script>alert('Invalid File Extension');</script>";
        }else{
            $newFileName = $fileName;;
            $targetPath = 'uploads/documents/' . $newFileName;

            if(move_uploaded_file($tmpName, $targetPath)){
                $query = "INSERT INTO upload_file (fileName,file, author, size, date) VALUES ('$newFileName', $docFile '$name', '$fileSize', '$uploadDate')";
                mysqli_query($conn, $query);

                echo "<script>alert('Image Added Successfully'); window.location.href = 'check.php';</script>";
            }else {
                echo "<script>alert('Failed to upload image');</script>";
            }

            // echo 'new fileName' . $newFileName ;
        }
    }
    
}



// Process form submission
// if ($_SERVER["REQUEST_METHOD"] == "POST") {
//     // Validate and sanitize inputs
//     $authorsName = mysqli_real_escape_string($conn, $_POST['authorsName']);

//     // Handle document file upload
//     $targetDirectory = "uploads/documents/";
//     $docFileName = $_FILES["docFiles"]["name"];
//     $docFileType = strtolower(pathinfo($docFileName, PATHINFO_EXTENSION));
//     $docFileSize = $_FILES["docFiles"]["size"];
//     $uploadDate = date("Y-m-d H:i:s"); // Current date and time

//     // Generate unique file name
//     $newFileName = $docFileName;
//     while (file_exists($targetDirectory . $newFileName)) {
//         $randomDigit = mt_rand(0, 9); // Generate random digit
//         $newFileName = $randomDigit . $docFileName;
//     }

//     $docFile = $targetDirectory . $newFileName;
//     move_uploaded_file($_FILES["docFiles"]["tmp_name"], $docFile);

//     // Handle uploader image upload
//     $uploaderImage = "uploads/images/" . basename($_FILES["uploader_image"]["name"]);
//     $imageFileType = strtolower(pathinfo($_FILES["uploader_image"]["name"], PATHINFO_EXTENSION));

//     if (!in_array($imageFileType, array("jpg", "jpeg", "png", "gif"))) {
//         $message = "Error: Only JPG, JPEG, PNG, and GIF files are allowed for uploader images.";
//         exit();
//     }
//     move_uploaded_file($_FILES["uploader_image"]["tmp_name"], $uploaderImage);

//     // Insert data into upload_file table
//     $sql = "INSERT INTO upload_file (fileName, file, author, image, size, date) VALUES ('$newFileName', '$docFile', '$authorsName', '$uploaderImage', '$docFileSize', '$uploadDate')";
//     if (mysqli_query($conn, $sql)) {
//         $message = "File uploaded successfully.";
//     } else {
//         $message = "Error: " . $sql . "<br>" . mysqli_error($conn);
//     }
//     mysqli_close($conn);
// }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add File</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .message {
            color: green;
            text-align: center;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="mainBody">
        <div class="left">
            <?php include_once('leftBar.php'); ?>
        </div>
        <div class="right">
            <div class="register">
                <form action="" method="post" autocomplete="off" method="post" enctype="multipart/form-data">
                    <h2>Add File</h2>
                    <?php if (!empty($message)): ?>
                        <div class="message"><?php echo $message; ?></div>
                    <?php endif; ?>
                    <label style="margin: 0;" for="">Upload file</label>
                    <input style="margin: 0;"  type="file" name="docFiles" id="docFiles" >
                    <input type="text" name="authorsName" id="authorsName" placeholder="Author's Name" required>
                    <label style="margin: 0;" for="">Upload Image</label>
                    <input style="margin: 0;" type="file" name="uploader_image" id="uploader_image" required>
                    <button type="submit" name="submit">Upload</button>
                </form>       
            </div>
        </div>
    </div>
</body>
</html>

